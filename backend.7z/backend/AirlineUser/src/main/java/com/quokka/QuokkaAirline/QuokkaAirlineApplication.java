package com.quokka.QuokkaAirline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuokkaAirlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuokkaAirlineApplication.class, args);
	}

}
