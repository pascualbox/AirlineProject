package com.quokka.QuokkaAirline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuokkaAirlineApplicationTests {

	@Test
	void contextLoads() {
	}

}
