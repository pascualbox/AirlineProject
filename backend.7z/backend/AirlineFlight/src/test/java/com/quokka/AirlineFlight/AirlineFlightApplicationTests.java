package com.quokka.AirlineFlight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineFlightApplicationTests {

	@Test
	void contextLoads() {
	}

}
