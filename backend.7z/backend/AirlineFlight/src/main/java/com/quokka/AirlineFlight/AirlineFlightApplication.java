package com.quokka.AirlineFlight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineFlightApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineFlightApplication.class, args);
	}

}
